import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import os
import re
import threading
import subprocess
import sys
from datetime import datetime

# ==================== CONFIG ====================
APP_TITLE = "نظام إدارة الموظفين"
HEADERS = [
    "رقم الموظف", "الاسم بالكامل", "المسمى الوظيفي", "القسم",
    "السن", "الرقم القومي", "العنوان", "رقم التليفون",
    "الحالة الاجتماعية", "رقم الطوارئ", "تاريخ الإضافة"
]

# Job title → Department prefix mapping
JOB_PREFIXES = {
    "مهندس": "ENG",
    "مهندس أول": "ENG",
    "مهندس مدني": "ENG",
    "مهندس كهربائي": "ENG",
    "مهندس ميكانيكي": "ENG",
    "فني": "TECH",
    "فني أول": "TECH",
    "تقني": "TECH",
    "مبرمج": "TECH",
    "محلل نظم": "TECH",
    "مدير": "ADM",
    "مدير قسم": "ADM",
    "مدير عام": "ADM",
    "سكرتير": "ADM",
    "محاسب": "ADM",
    "موارد بشرية": "ADM",
    "مسؤول إداري": "ADM",
}

DEPT_DEFAULTS = {
    "ENG": "هندسة",
    "TECH": "تقنية",
    "ADM": "إدارة",
}

MARITAL_STATUS = ["أعزب/عزباء", "متزوج/متزوجة", "مطلق/مطلقة", "أرمل/أرملة"]

COLORS = {
    "bg": "#0F172A",
    "surface": "#1E293B",
    "card": "#243044",
    "accent": "#3B82F6",
    "accent2": "#10B981",
    "text": "#F1F5F9",
    "text_muted": "#94A3B8",
    "border": "#334155",
    "error": "#EF4444",
    "success": "#22C55E",
    "warning": "#F59E0B",
    "header_bg": "#1E3A5F",
}

FONT_AR = "Tahoma"
FONT_EN = "Consolas"

# ==================== EXCEL HELPERS ====================

def get_next_id(ws, prefix):
    """Scan column A for existing IDs with this prefix and return next one."""
    max_num = 0
    pattern = re.compile(rf"^ECN-{prefix}-(\d+)$")
    for row in ws.iter_rows(min_row=2, max_col=1, values_only=True):
        if row[0]:
            m = pattern.match(str(row[0]))
            if m:
                max_num = max(max_num, int(m.group(1)))
    return f"ECN-{prefix}-{str(max_num + 1).zfill(3)}"


def determine_prefix(job_title):
    """Map job title to ID prefix."""
    for key, prefix in JOB_PREFIXES.items():
        if key in job_title:
            return prefix
    # fallback: first 3 letters uppercase
    return job_title[:3].upper() if job_title else "ADM"


def style_header_row(ws):
    header_fill = PatternFill("solid", fgColor="1E3A5F")
    header_font = Font(name=FONT_AR, bold=True, color="FFFFFF", size=11)
    thin = Side(style='thin', color="334155")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for col_num, header in enumerate(HEADERS, 1):
        cell = ws.cell(row=1, column=col_num, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border
    ws.row_dimensions[1].height = 30


def style_data_row(ws, row_num):
    thin = Side(style='thin', color="334155")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    fill = PatternFill("solid", fgColor="1E293B") if row_num % 2 == 0 else PatternFill("solid", fgColor="243044")
    font = Font(name=FONT_AR, size=10, color="F1F5F9")
    for col in range(1, len(HEADERS) + 1):
        cell = ws.cell(row=row_num, column=col)
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border


def auto_fit_columns(ws):
    col_widths = [18, 22, 20, 16, 8, 20, 25, 16, 18, 18, 16]
    for i, width in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = width


def create_new_workbook(path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "الموظفين"
    ws.sheet_view.rightToLeft = True
    style_header_row(ws)
    auto_fit_columns(ws)
    wb.save(path)
    return wb


def load_or_create_workbook(path):
    if os.path.exists(path):
        wb = openpyxl.load_workbook(path)
        ws = wb.active
        # Make sure headers exist
        if ws.max_row < 1 or ws.cell(1, 1).value != "رقم الموظف":
            style_header_row(ws)
            auto_fit_columns(ws)
            wb.save(path)
        return wb
    else:
        return create_new_workbook(path)


def add_employee_to_excel(path, employee_data):
    wb = load_or_create_workbook(path)
    ws = wb.active
    ws.sheet_view.rightToLeft = True
    next_row = ws.max_row + 1
    for col, value in enumerate(employee_data, 1):
        ws.cell(row=next_row, column=col, value=value)
    style_data_row(ws, next_row)
    auto_fit_columns(ws)
    wb.save(path)
    return True


# ==================== UI ====================

class EmployeeApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("900x700")
        self.root.configure(bg=COLORS["bg"])
        self.root.resizable(True, True)
        self.excel_path = tk.StringVar(value="")
        self.entries = {}
        self.setup_styles()
        self.build_ui()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background=COLORS["bg"])
        style.configure("Card.TFrame", background=COLORS["card"])
        style.configure("Surface.TFrame", background=COLORS["surface"])
        style.configure("TLabel",
            background=COLORS["bg"], foreground=COLORS["text"],
            font=(FONT_AR, 10))
        style.configure("Header.TLabel",
            background=COLORS["bg"], foreground=COLORS["text"],
            font=(FONT_AR, 18, "bold"))
        style.configure("Sub.TLabel",
            background=COLORS["bg"], foreground=COLORS["text_muted"],
            font=(FONT_AR, 9))
        style.configure("Card.TLabel",
            background=COLORS["card"], foreground=COLORS["text"],
            font=(FONT_AR, 10))
        style.configure("CardSub.TLabel",
            background=COLORS["card"], foreground=COLORS["text_muted"],
            font=(FONT_AR, 9))
        style.configure("Accent.TButton",
            background=COLORS["accent"], foreground="white",
            font=(FONT_AR, 11, "bold"), padding=(12, 8), relief="flat")
        style.map("Accent.TButton",
            background=[("active", "#2563EB"), ("pressed", "#1D4ED8")])
        style.configure("Success.TButton",
            background=COLORS["accent2"], foreground="white",
            font=(FONT_AR, 10, "bold"), padding=(10, 6), relief="flat")
        style.map("Success.TButton",
            background=[("active", "#059669")])
        style.configure("Outline.TButton",
            background=COLORS["surface"], foreground=COLORS["text"],
            font=(FONT_AR, 10), padding=(10, 6), relief="flat",
            borderwidth=1)
        style.configure("TEntry",
            fieldbackground=COLORS["surface"],
            foreground=COLORS["text"],
            insertcolor=COLORS["text"],
            borderwidth=1, relief="flat",
            font=(FONT_AR, 10))
        style.configure("TCombobox",
            fieldbackground=COLORS["surface"],
            background=COLORS["surface"],
            foreground=COLORS["text"],
            selectbackground=COLORS["accent"],
            font=(FONT_AR, 10))
        style.map("TCombobox",
            fieldbackground=[("readonly", COLORS["surface"])],
            foreground=[("readonly", COLORS["text"])])
        style.configure("Horizontal.TSeparator", background=COLORS["border"])

    def build_ui(self):
        # ---- Header ----
        header_frame = tk.Frame(self.root, bg=COLORS["surface"], pady=16)
        header_frame.pack(fill="x", padx=0, pady=0)

        tk.Label(header_frame, text="👥  نظام إدارة الموظفين",
                 bg=COLORS["surface"], fg=COLORS["text"],
                 font=(FONT_AR, 16, "bold")).pack(side="right", padx=20)
        brand_frame = tk.Frame(header_frame, bg=COLORS["surface"])
        brand_frame.pack(side="left", padx=20)
        tk.Label(brand_frame, text="Econnect Telecom",
                 bg=COLORS["surface"], fg="#2D4A6B",
                 font=(FONT_EN, 13, "bold")).pack(anchor="w")
        tk.Label(brand_frame, text="Creat by ENG Omar Gamal",
                 bg=COLORS["surface"], fg="#2D4A6B",
                 font=(FONT_EN, 13, "bold")).pack(anchor="w")

        # ---- File selection ----
        file_frame = tk.Frame(self.root, bg=COLORS["card"], pady=12, padx=16)
        file_frame.pack(fill="x", padx=16, pady=(12, 4))

        tk.Label(file_frame, text="📂  ملف Excel:", bg=COLORS["card"],
                 fg=COLORS["text_muted"], font=(FONT_AR, 10)).pack(side="right")

        path_entry = tk.Entry(file_frame, textvariable=self.excel_path,
                              bg=COLORS["surface"], fg=COLORS["text"],
                              font=(FONT_EN, 9), relief="flat",
                              insertbackground=COLORS["text"], width=40)
        path_entry.pack(side="right", padx=8, ipady=4)

        tk.Button(file_frame, text="📁 فتح ملف موجود",
                  command=self.open_existing_file,
                  bg=COLORS["surface"], fg=COLORS["text"],
                  font=(FONT_AR, 9), relief="flat",
                  activebackground=COLORS["border"],
                  cursor="hand2").pack(side="right", padx=4)

        tk.Button(file_frame, text="☁️ Google Drive",
                  command=self.open_from_drive,
                  bg="#1a6b3c", fg="white",
                  font=(FONT_AR, 9, "bold"), relief="flat",
                  activebackground="#155c33",
                  cursor="hand2").pack(side="right", padx=4)

        tk.Button(file_frame, text="✨ ملف جديد",
                  command=self.create_new_file,
                  bg=COLORS["accent"], fg="white",
                  font=(FONT_AR, 9, "bold"), relief="flat",
                  activebackground="#2563EB",
                  cursor="hand2").pack(side="right", padx=4)

        # ---- Scrollable form ----
        canvas_frame = tk.Frame(self.root, bg=COLORS["bg"])
        canvas_frame.pack(fill="both", expand=True, padx=16, pady=8)

        canvas = tk.Canvas(canvas_frame, bg=COLORS["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(canvas_frame, orient="vertical", command=canvas.yview)
        self.scroll_frame = tk.Frame(canvas, bg=COLORS["bg"])

        self.scroll_frame.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(-1*(e.delta//120), "units"))

        self.build_form()

        # ---- Bottom buttons ----
        btn_frame = tk.Frame(self.root, bg=COLORS["surface"], pady=14)
        btn_frame.pack(fill="x", side="bottom")

        tk.Button(btn_frame, text="✅  إضافة الموظف",
                  command=self.submit,
                  bg=COLORS["accent2"], fg="white",
                  font=(FONT_AR, 12, "bold"), relief="flat",
                  padx=24, pady=8, cursor="hand2",
                  activebackground="#059669").pack(side="right", padx=16)

        tk.Button(btn_frame, text="🗑  مسح البيانات",
                  command=self.clear_form,
                  bg=COLORS["surface"], fg=COLORS["text_muted"],
                  font=(FONT_AR, 10), relief="flat",
                  padx=16, pady=8, cursor="hand2",
                  activebackground=COLORS["border"]).pack(side="right", padx=4)

        # Status bar
        self.status_var = tk.StringVar(value="جاهز — اختر ملف Excel أو أنشئ ملفاً جديداً")
        self.status_bar = tk.Label(self.root, textvariable=self.status_var,
                                   bg=COLORS["bg"], fg=COLORS["text_muted"],
                                   font=(FONT_AR, 9), anchor="e")
        self.status_bar.pack(fill="x", padx=16, pady=(0, 2))

        # Footer watermark
        footer = tk.Frame(self.root, bg=COLORS["bg"])
        footer.pack(fill="x", pady=(0, 4))
        tk.Label(footer, text="Econnect Telecom  •  ENG Omar Gamal Kassem",
                 bg=COLORS["bg"], fg="#1A2A3A",
                 font=(FONT_EN, 7)).pack(side="left", padx=16)

    def build_form(self):
        f = self.scroll_frame

        def section(title, icon=""):
            sec = tk.Frame(f, bg=COLORS["surface"], pady=6, padx=12)
            sec.pack(fill="x", pady=(8, 0))
            tk.Label(sec, text=f"{icon}  {title}",
                     bg=COLORS["surface"], fg=COLORS["accent"],
                     font=(FONT_AR, 11, "bold")).pack(anchor="e")
            return sec

        def field(parent, label, key, widget_type="entry", options=None, placeholder=""):
            row = tk.Frame(parent, bg=COLORS["card"], pady=5, padx=12)
            row.pack(fill="x", pady=1)
            tk.Label(row, text=label + " :", bg=COLORS["card"],
                     fg=COLORS["text"], font=(FONT_AR, 10),
                     width=22, anchor="e").pack(side="right")
            if widget_type == "combo":
                var = tk.StringVar()
                widget = ttk.Combobox(row, textvariable=var, values=options,
                                      width=32, state="readonly")
                if options:
                    widget.set(options[0])
                widget.pack(side="right", padx=6, ipady=4)
                self.entries[key] = var
            else:
                var = tk.StringVar()
                widget = tk.Entry(row, textvariable=var, width=35,
                                  bg=COLORS["surface"], fg=COLORS["text"],
                                  font=(FONT_AR, 10), relief="flat",
                                  insertbackground=COLORS["text"])
                widget.pack(side="right", padx=6, ipady=5)
                if placeholder:
                    widget.insert(0, placeholder)
                    widget.config(fg=COLORS["text_muted"])
                    def on_focus_in(e, w=widget, p=placeholder):
                        if w.get() == p:
                            w.delete(0, "end")
                            w.config(fg=COLORS["text"])
                    def on_focus_out(e, w=widget, p=placeholder, var=var):
                        if not w.get():
                            w.insert(0, p)
                            w.config(fg=COLORS["text_muted"])
                    widget.bind("<FocusIn>", on_focus_in)
                    widget.bind("<FocusOut>", on_focus_out)
                self.entries[key] = var

        # --- Section 1: Personal Info ---
        s1 = section("البيانات الشخصية", "👤")
        field(s1, "الاسم بالكامل", "name", placeholder="مثال: محمد أحمد علي")
        field(s1, "السن", "age", placeholder="مثال: 30")
        field(s1, "الرقم القومي", "national_id", placeholder="14 رقم")
        field(s1, "الحالة الاجتماعية", "marital", "combo", MARITAL_STATUS)
        field(s1, "العنوان", "address", placeholder="المحافظة، المدينة، الشارع")

        # --- Section 2: Job Info ---
        s2 = section("البيانات الوظيفية", "💼")
        job_titles = list(JOB_PREFIXES.keys()) + ["أخرى"]
        field(s2, "المسمى الوظيفي", "job_title", "combo", job_titles)
        dept_options = ["هندسة", "تقنية", "إدارة", "مبيعات", "أخرى"]
        field(s2, "القسم", "department", "combo", dept_options)

        # --- Section 3: Contact ---
        s3 = section("بيانات التواصل", "📞")
        field(s3, "رقم التليفون", "phone", placeholder="01X XXXX XXXX")
        field(s3, "رقم الطوارئ", "emergency", placeholder="01X XXXX XXXX")

        # --- ID Preview ---
        id_frame = tk.Frame(f, bg=COLORS["header_bg"], pady=10, padx=16)
        id_frame.pack(fill="x", pady=(10, 4))
        tk.Label(id_frame, text="رقم الموظف المقترح:",
                 bg=COLORS["header_bg"], fg=COLORS["text_muted"],
                 font=(FONT_AR, 9)).pack(side="right")
        self.id_preview = tk.Label(id_frame,
                                   text="اختر ملف وحدد المسمى الوظيفي أولاً",
                                   bg=COLORS["header_bg"], fg=COLORS["warning"],
                                   font=(FONT_EN, 12, "bold"))
        self.id_preview.pack(side="right", padx=10)

        # Bind job title change to update preview
        self.entries["job_title"].trace_add("write", self.update_id_preview)

    def update_id_preview(self, *args):
        job = self.entries["job_title"].get()
        path = self.excel_path.get()
        if not path or not job:
            self.id_preview.config(text="—", fg=COLORS["text_muted"])
            return
        prefix = determine_prefix(job)
        if os.path.exists(path):
            try:
                wb = openpyxl.load_workbook(path)
                ws = wb.active
                next_id = get_next_id(ws, prefix)
                self.id_preview.config(text=next_id, fg=COLORS["accent2"])
            except Exception:
                self.id_preview.config(text=f"ECN-{prefix}-001", fg=COLORS["warning"])
        else:
            self.id_preview.config(text=f"ECN-{prefix}-001", fg=COLORS["text_muted"])

    def open_existing_file(self):
        path = filedialog.askopenfilename(
            title="اختر ملف Excel",
            filetypes=[("Excel Files", "*.xlsx *.xlsm"), ("All Files", "*.*")]
        )
        if path:
            self.excel_path.set(path)
            self.set_status(f"✅  تم تحميل: {os.path.basename(path)}", "success")
            self.update_id_preview()

    def create_new_file(self):
        path = filedialog.asksaveasfilename(
            title="إنشاء ملف Excel جديد",
            defaultextension=".xlsx",
            filetypes=[("Excel Files", "*.xlsx")],
            initialfile="قائمة_الموظفين.xlsx"
        )
        if path:
            create_new_workbook(path)
            self.excel_path.set(path)
            self.set_status(f"✨  تم إنشاء ملف جديد: {os.path.basename(path)}", "success")
            self.update_id_preview()

    def open_from_drive(self):
        """Download Excel/Sheets from Google Drive or Google Sheets link."""
        drive_win = tk.Toplevel(self.root)
        drive_win.title("فتح من Google Drive / Sheets")
        drive_win.geometry("560x310")
        drive_win.configure(bg=COLORS["bg"])
        drive_win.resizable(False, False)
        drive_win.grab_set()

        tk.Label(drive_win, text="☁️  فتح من Google Drive / Sheets",
                 bg=COLORS["bg"], fg=COLORS["text"],
                 font=(FONT_AR, 13, "bold")).pack(pady=(18, 4))

        tk.Label(drive_win,
                 text="الصق لينك المشاركة (Drive أو Sheets):",
                 bg=COLORS["bg"], fg=COLORS["text_muted"],
                 font=(FONT_AR, 9)).pack(pady=(0, 4))

        link_var = tk.StringVar()
        link_entry = tk.Entry(drive_win, textvariable=link_var, width=60,
                              bg=COLORS["surface"], fg=COLORS["text"],
                              font=(FONT_EN, 8), relief="flat",
                              insertbackground=COLORS["text"])
        link_entry.pack(padx=20, ipady=6)
        link_entry.focus()

        tk.Label(drive_win,
                 text="✅ يدعم: docs.google.com/spreadsheets/...   |   drive.google.com/file/...",
                 bg=COLORS["bg"], fg="#1A4A2A",
                 font=(FONT_EN, 7)).pack(pady=(3, 0))

        # Save path
        save_frame = tk.Frame(drive_win, bg=COLORS["bg"])
        save_frame.pack(fill="x", padx=20, pady=(10, 0))
        tk.Label(save_frame, text="حفظ في:",
                 bg=COLORS["bg"], fg=COLORS["text_muted"],
                 font=(FONT_AR, 9)).pack(side="right")
        save_var = tk.StringVar(value=os.path.join(
            os.path.expanduser("~"), "Desktop", "قائمة_الموظفين.xlsx"))
        tk.Entry(save_frame, textvariable=save_var, width=40,
                 bg=COLORS["surface"], fg=COLORS["text"],
                 font=(FONT_EN, 8), relief="flat",
                 insertbackground=COLORS["text"]).pack(side="right", padx=6, ipady=4)
        tk.Button(save_frame, text="📂",
                  command=lambda: save_var.set(
                      filedialog.asksaveasfilename(
                          defaultextension=".xlsx",
                          filetypes=[("Excel", "*.xlsx")],
                          initialfile="قائمة_الموظفين.xlsx") or save_var.get()),
                  bg=COLORS["surface"], fg=COLORS["text"],
                  relief="flat", cursor="hand2").pack(side="right")

        status_lbl = tk.Label(drive_win, text="",
                              bg=COLORS["bg"], fg=COLORS["warning"],
                              font=(FONT_AR, 9))
        status_lbl.pack(pady=(8, 0))

        def do_download():
            link = link_var.get().strip()
            save_path = save_var.get().strip()
            if not link:
                status_lbl.config(text="⚠️  أدخل اللينك أولاً", fg=COLORS["warning"])
                return
            if not save_path:
                status_lbl.config(text="⚠️  اختر مكان الحفظ أولاً", fg=COLORS["warning"])
                return

            direct_url = self._gdrive_direct_url(link)
            if not direct_url:
                status_lbl.config(
                    text="❌  اللينك غير صحيح — لازم يكون Google Drive أو Google Sheets",
                    fg=COLORS["error"])
                return

            status_lbl.config(text="⏳  جاري التحميل...", fg=COLORS["warning"])
            drive_win.update()

            def download_thread():
                try:
                    try:
                        import requests
                    except ImportError:
                        subprocess.check_call(
                            [sys.executable, "-m", "pip", "install", "requests", "-q"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        import requests

                    resp = requests.get(direct_url, timeout=30)
                    resp.raise_for_status()

                    with open(save_path, "wb") as f:
                        f.write(resp.content)

                    # Verify valid xlsx
                    openpyxl.load_workbook(save_path)
                    self.root.after(0, lambda: self._drive_success(drive_win, save_path))

                except Exception as e:
                    if os.path.exists(save_path):
                        try: os.remove(save_path)
                        except: pass
                    self.root.after(0, lambda err=e: status_lbl.config(
                        text=f"❌  فشل: {str(err)[:70]}", fg=COLORS["error"]))

            threading.Thread(target=download_thread, daemon=True).start()

        btn_row = tk.Frame(drive_win, bg=COLORS["bg"])
        btn_row.pack(pady=(6, 0))
        tk.Button(btn_row, text="⬇️  تحميل وفتح",
                  command=do_download,
                  bg=COLORS["accent2"], fg="white",
                  font=(FONT_AR, 10, "bold"), relief="flat",
                  padx=16, pady=6, cursor="hand2").pack(side="right", padx=8)
        tk.Button(btn_row, text="إلغاء",
                  command=drive_win.destroy,
                  bg=COLORS["surface"], fg=COLORS["text_muted"],
                  font=(FONT_AR, 9), relief="flat",
                  padx=12, pady=6, cursor="hand2").pack(side="right")

    def _gdrive_direct_url(self, link):
        """Convert any Google Drive or Google Sheets link to direct xlsx download URL."""

        # ── Google Sheets ──────────────────────────────────────────────────────
        # https://docs.google.com/spreadsheets/d/FILE_ID/edit?gid=...
        m = re.search(r"docs\.google\.com/spreadsheets/d/([a-zA-Z0-9_-]+)", link)
        if m:
            file_id = m.group(1)
            # Extract specific sheet (gid) if present
            gid_m = re.search(r"[#&?]gid=(\d+)", link)
            if gid_m:
                gid = gid_m.group(1)
                return (f"https://docs.google.com/spreadsheets/d/{file_id}"
                        f"/export?format=xlsx&gid={gid}")
            return (f"https://docs.google.com/spreadsheets/d/{file_id}"
                    f"/export?format=xlsx")

        # ── Google Drive file ──────────────────────────────────────────────────
        # https://drive.google.com/file/d/FILE_ID/view
        m = re.search(r"drive\.google\.com/file/d/([a-zA-Z0-9_-]+)", link)
        if m:
            file_id = m.group(1)
            return (f"https://drive.google.com/uc"
                    f"?export=download&id={file_id}&confirm=t")

        # ── Drive with ?id= param ──────────────────────────────────────────────
        m = re.search(r"[?&]id=([a-zA-Z0-9_-]+)", link)
        if m:
            file_id = m.group(1)
            return (f"https://drive.google.com/uc"
                    f"?export=download&id={file_id}&confirm=t")

        return None

    def _drive_success(self, win, path):
        win.destroy()
        self.excel_path.set(path)
        self.set_status(f"☁️  تم التحميل من Drive: {os.path.basename(path)}", "success")
        self.update_id_preview()
        messagebox.showinfo("تم!", f"تم تحميل الملف بنجاح وحفظه في:\n{path}")

    def get_field(self, key, placeholder=None):
        val = self.entries[key].get().strip()
        if placeholder and val == placeholder:
            return ""
        return val

    def submit(self):
        path = self.excel_path.get().strip()
        if not path:
            messagebox.showwarning("تنبيه", "يرجى اختيار ملف Excel أولاً!")
            return

        name = self.get_field("name", "مثال: محمد أحمد علي")
        job = self.get_field("job_title")
        dept = self.get_field("department")
        age = self.get_field("age", "مثال: 30")
        national_id = self.get_field("national_id", "14 رقم")
        address = self.get_field("address", "المحافظة، المدينة، الشارع")
        phone = self.get_field("phone", "01X XXXX XXXX")
        marital = self.get_field("marital")
        emergency = self.get_field("emergency", "01X XXXX XXXX")

        errors = []
        if not name:
            errors.append("• الاسم بالكامل مطلوب")
        if not job:
            errors.append("• المسمى الوظيفي مطلوب")
        if not age or not age.isdigit():
            errors.append("• السن يجب أن يكون رقماً صحيحاً")
        if not phone:
            errors.append("• رقم التليفون مطلوب")

        if errors:
            messagebox.showerror("بيانات ناقصة", "\n".join(errors))
            return

        prefix = determine_prefix(job)

        try:
            wb = load_or_create_workbook(path)
            ws = wb.active
            emp_id = get_next_id(ws, prefix)
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
            row_data = [
                emp_id, name, job, dept, int(age),
                national_id, address, phone,
                marital, emergency, timestamp
            ]
            next_row = ws.max_row + 1
            for col, val in enumerate(row_data, 1):
                ws.cell(row=next_row, column=col, value=val)
            style_data_row(ws, next_row)
            auto_fit_columns(ws)
            ws.sheet_view.rightToLeft = True
            wb.save(path)
        except Exception as e:
            messagebox.showerror("خطأ", f"حدث خطأ أثناء الحفظ:\n{e}")
            return

        # Success popup
        msg = (
            f"✅ تم إضافة الموظف بنجاح!\n\n"
            f"الاسم: {name}\n"
            f"رقم الموظف: {emp_id}\n"
            f"المسمى: {job}\n"
            f"القسم: {dept}"
        )
        messagebox.showinfo("تم الإضافة", msg)
        self.set_status(f"✅  تمت إضافة: {name}  |  ID: {emp_id}", "success")
        self.clear_form()
        self.update_id_preview()

    def clear_form(self):
        placeholders = {
            "name": "مثال: محمد أحمد علي",
            "age": "مثال: 30",
            "national_id": "14 رقم",
            "address": "المحافظة، المدينة، الشارع",
            "phone": "01X XXXX XXXX",
            "emergency": "01X XXXX XXXX",
        }
        for key, ph in placeholders.items():
            if key in self.entries:
                self.entries[key].set(ph)
        combos = ["job_title", "department", "marital"]
        defaults = {
            "job_title": list(JOB_PREFIXES.keys())[0],
            "department": "هندسة",
            "marital": MARITAL_STATUS[0],
        }
        for key in combos:
            if key in self.entries:
                self.entries[key].set(defaults.get(key, ""))
        self.set_status("جاهز لإدخال موظف جديد", "normal")

    def set_status(self, msg, kind="normal"):
        colors = {"success": COLORS["success"], "error": COLORS["error"],
                  "warning": COLORS["warning"], "normal": COLORS["text_muted"]}
        self.status_var.set(msg)
        self.status_bar.config(fg=colors.get(kind, COLORS["text_muted"]))


# ==================== MAIN ====================

if __name__ == "__main__":
    root = tk.Tk()
    app = EmployeeApp(root)
    root.mainloop()
